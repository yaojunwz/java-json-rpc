package com.yaojun.java_json_rpc.handler;

/**
 * @Author: yaojun
 * @Date: 2018/12/18 14:08
 */

public class TestHandlerImp implements TestHandler {
}
