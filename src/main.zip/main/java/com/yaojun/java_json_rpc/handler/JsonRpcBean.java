package com.yaojun.java_json_rpc.handler;

/**
 * @Author: yaojun
 * @Date: 2018/12/25 19:28
 */
public class JsonRpcBean {
    private String name;
    private Integer age;
    private String hobby;
}
