package com.yaojun.java_json_rpc.client;

/**
 * @Author: yaojun
 * @Date: 2018/12/20 11:04
 */
public class JsonRpcException extends Exception {
    public JsonRpcException(String message) {
        super(message);
    }
}
